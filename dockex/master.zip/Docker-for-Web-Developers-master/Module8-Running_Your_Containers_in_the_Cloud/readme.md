## This module has been deprecated

Docker Cloud services were discontinued by Docker on May 21, 2018

You can get to the project used here though:

Code with Dan Docker Services: https://github.com/DanWahlin/CodeWithDanDockerServices
